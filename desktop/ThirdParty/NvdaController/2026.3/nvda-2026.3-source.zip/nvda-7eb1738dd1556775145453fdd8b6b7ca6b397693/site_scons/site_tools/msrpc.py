###
# This file is a part of the NVDA project.
# URL: http://www.nvda-project.org/
# Copyright 2006-2010 NVDA contributers.
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License version 2.0, as published by
# the Free Software Foundation.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# This license can be found at:
# http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
###

# MSRPC tool
# Provides the MSRPCStubs builder which can use MIDL to generate header, client stub, and server stub files from an IDL.

from SCons import Util
from SCons.Builder import Builder


# This build emitter tells the builder that a header file, a client stub c file, and a server stub c file will be generated
def MSRPCStubs_buildEmitter(target, source, env):
	base, ext = Util.splitext(str(target[0] if len(target) > 0 else source[0]))  # noqa: RUF059
	newTargets = ["%s.h" % base]  # noqa: UP031
	if not env["MSRPCStubs_noServer"]:
		newTargets.append("%s_S.c" % base)  # noqa: UP031
	if not env["MSRPCStubs_noClient"]:
		newTargets.append("%s_C.c" % base)  # noqa: UP031
	return (newTargets, source)


def MSRPCStubs_builder_actionGenerator(target, source, env, for_signature):
	sources = []
	for src in source:
		src = str(src)
		if src.endswith(".acf"):
			sources.append("/acf %s" % src)  # noqa: UP031
		else:
			sources.append(src)
	sources = " ".join(sources)
	targets = []
	for tg in target:
		tg = str(tg)
		if tg.endswith(".h"):
			targets.append("/header %s" % tg)  # noqa: UP031
		elif tg.endswith("_S.c"):
			targets.append("/sstub %s" % tg)  # noqa: UP031
		elif tg.endswith("_C.c"):
			targets.append("/cstub %s" % tg)  # noqa: UP031
		else:
			raise ValueError("Don't know what to do with %s" % tg)  # noqa: UP031
	targets = " ".join(targets)
	noServer = "/server none" if env.get("MSRPCStubs_noServer", False) else ""
	noClient = "/client none" if env.get("MSRPCStubs_noClient", False) else ""

	prefix = env.get("MSRPCStubs_prefix", "")
	if prefix:
		prefix = "/prefix all %s" % prefix  # noqa: UP031
	serverPrefix = env.get("MSRPCStubs_serverPrefix", "")
	if serverPrefix:
		serverPrefix = "/prefix server %s" % serverPrefix  # noqa: UP031
	clientPrefix = env.get("MSRPCStubs_clientPrefix", "")
	if clientPrefix:
		clientPrefix = "/prefix client %s" % clientPrefix  # noqa: UP031

	return " ".join(  # noqa: FLY002
		["${MIDL}", "${MIDLFLAGS}", noServer, noClient, prefix, serverPrefix, clientPrefix, targets, sources],
	)


MSRPCStubs_builder = Builder(
	generator=MSRPCStubs_builder_actionGenerator,
	src_suffix=[".idl", ".acf"],
	emitter=MSRPCStubs_buildEmitter,
)


def exists(env):
	from SCons.Tool import midl

	return midl.exists(env)


def generate(env):
	if "MIDL" not in env:
		from SCons.Tool import midl

		midl.generate(env)
	env["BUILDERS"]["MSRPCStubs"] = MSRPCStubs_builder
	env["MSRPCStubs_noServer"] = False
	env["MSRPCStubs_noClient"] = False
